apt python3-pip -y
pip3 install flask
pip3 install flask_wtf
uzip project-shadowsocksr-panel.zip
cd project-shadowsocksr-panel
nohup python3 manage.py