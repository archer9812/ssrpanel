dist = {
    "101":"1234",
    "102":"123142",
    "1231":"124124"
}
dist["1234"] = "2412"
dist.pop("101")
for i in dist:
    print(i,dist[i])